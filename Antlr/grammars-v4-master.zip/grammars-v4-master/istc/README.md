# ISTC Grammar

An ANTLR4 grammar for [ISTC Numbers](https://en.wikipedia.org/wiki/International_Standard_Text_Code).

