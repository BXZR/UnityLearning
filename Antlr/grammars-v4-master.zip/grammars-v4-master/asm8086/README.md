# 8086 Assembler Grammar

An ANTLR4 grammar for [Intel 8086](https://en.wikipedia.org/wiki/Intel_8086) files.  

Created for the purpose of parsing the [CP/M Source code](http://www.cpm.z80.de/source.html)

Examples code is from [here](http://www.cpm.z80.de/download/c8611src.zip)

