/**
 * A description text.
 * 
 * @see A first block tag
 * @see A second block tag
 *      with multiple lines
 */