# COOL

Classroom Object Oriented Language is a widely used language in CS classes.

This Grammar defination comes from [COOL manual](http://sist.shanghaitech.edu.cn/faculty/songfu/course/spring2017/cs131/COOL/COOLAid.pdf).

This is a byproduct from a COOL-to-javascript compiler.
