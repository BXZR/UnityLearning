# 8080 Assembler Grammar

An ANTLR4 grammar for [Intel 8080](https://en.wikipedia.org/wiki/Intel_8080) files.  

Created for the purpose of parsing the [CP/M Source code](http://www.cpm.z80.de/source.html)
