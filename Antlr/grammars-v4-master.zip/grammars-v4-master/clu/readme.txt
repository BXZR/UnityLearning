clu grammar

https://en.wikipedia.org/wiki/CLU_(programming_language)

Grammar contains mutually recursive rulea which need to be repaired