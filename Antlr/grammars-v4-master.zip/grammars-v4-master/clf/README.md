# CLF Grammar

An ANTLR4 grammar for [Common Log Format](https://en.wikipedia.org/wiki/Common_Log_Format)
files and [Combined Log Format](https://httpd.apache.org/docs/1.3/logs.html).

