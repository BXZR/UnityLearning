# GML Grammar

An ANTLR4 grammar for [GML](https://en.wikipedia.org/wiki/Graph_Modelling_Language) files.
