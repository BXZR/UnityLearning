﻿using System;
using UnityEngine;
using UnityEditor;

namespace Magic.GameEditor
{
    public class TerrainToMesh
    {
        [Serializable]
        public class TerrainConvertInfo
        {
            public const int maxVertexCount = 65000;
            public int chunkCountHorizontal = 1;
            public int chunkCountVertical = 1;
            public int vertexCountHorizontal = 50;
            public int vertexCountVertical = 50;
            public bool generateSkirt = false;
            public float skirtGroundLevel = 0;

            public TerrainConvertInfo()
            {
                this.Reset();
            }

            public TerrainConvertInfo(TerrainToMesh.TerrainConvertInfo _right)
            {
                this.chunkCountHorizontal = _right.chunkCountHorizontal;
                this.chunkCountVertical = _right.chunkCountVertical;
                this.vertexCountHorizontal = _right.vertexCountHorizontal;
                this.vertexCountVertical = _right.vertexCountVertical;
                this.generateSkirt = _right.generateSkirt;
                this.skirtGroundLevel = _right.skirtGroundLevel;
            }

            public void Reset()
            {
                this.chunkCountHorizontal = 1;
                this.chunkCountVertical = 1;
                this.vertexCountHorizontal = 25;
                this.vertexCountVertical = 25;
                this.generateSkirt = false;
                this.skirtGroundLevel = 0.0f;
            }

            public int GetChunkCount()
            {
                if (this.chunkCountHorizontal < 1)
                    this.chunkCountHorizontal = 1;
                if (this.chunkCountVertical < 1)
                    this.chunkCountVertical = 1;
                return this.chunkCountHorizontal * this.chunkCountVertical;
            }

            public int GetVertexCountPerChunk()
            {
                int num = 0;
                if (this.generateSkirt)
                    num = 2 * (this.vertexCountHorizontal + this.vertexCountVertical);
                return this.vertexCountHorizontal * this.vertexCountVertical + num;
            }

            public int GetVertexCountTotal()
            {
                return this.GetChunkCount() * this.GetVertexCountPerChunk();
            }

            public int GetTriangleCountPerChunk()
            {
                int num = 0;
                if (this.generateSkirt)
                    num = 2 * (this.vertexCountHorizontal + this.vertexCountVertical) * 2;
                return (this.vertexCountHorizontal - 1) * (this.vertexCountVertical - 1) * 2 + num;
            }

            public int GetTriangleCountTotal()
            {
                return this.GetChunkCount() * this.GetTriangleCountPerChunk();
            }
        }
    }
}