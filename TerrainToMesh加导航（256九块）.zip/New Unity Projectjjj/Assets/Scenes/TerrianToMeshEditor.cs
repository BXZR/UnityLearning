﻿namespace Magic.GameEditor
{
    using System.Collections.Generic;
    using UnityEditor;
    using UnityEngine;

    public class TerrianToMeshEditor : EditorWindow
    {
        [MenuItem("[Framework]/TerrianToMesh/地图/添加")]

        static void AddWindow()
        {
            //创建窗口
            TerrianToMeshEditor window =
                (TerrianToMeshEditor) EditorWindow.GetWindow(typeof(TerrianToMeshEditor), false, "设置TerrianToMesh参数");
            window.Show();
        }

        //输入文字的内容
        private int chunkCountHorizontal = 1;
        private int chunkCountVertical = 1;
        private int vertexCountHorizontal = 50;
        private int vertexCountVertical = 50;
        private bool generateBasemap = false;
        private bool attachMeshCollider = true;
        GameObject[] selectedGameObjects;

        [InitializeOnLoadMethod]
        public void Awake()
        {
            OnSelectionChange();
        }

        void OnGUI()
        {
            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("水平面数:");
            chunkCountHorizontal = EditorGUILayout.IntField(chunkCountHorizontal);

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("垂直面数:");
            chunkCountVertical = EditorGUILayout.IntField(chunkCountVertical);

            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("水平顶点数:");
            vertexCountHorizontal = EditorGUILayout.IntField(vertexCountHorizontal);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("垂直顶点数:");
            vertexCountVertical = EditorGUILayout.IntField(vertexCountVertical);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("否是自动添加MeshCollider:");
            attachMeshCollider = EditorGUILayout.Toggle(attachMeshCollider);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("否是自动生成BaseMap:");
            generateBasemap = EditorGUILayout.Toggle(generateBasemap);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            GUILayout.Label("当前选中了" + selectedGameObjects.Length + "个物体");
            EditorGUILayout.Space();

            if (GUILayout.Button("根据场景中的Terrian创建Mesh", GUILayout.MinHeight(20)))
            {
                RunTime_Terrain_Convertion.convertInfo  = new TerrainToMesh.TerrainConvertInfo();
                RunTime_Terrain_Convertion.convertInfo.chunkCountHorizontal = chunkCountHorizontal;
                RunTime_Terrain_Convertion.convertInfo.chunkCountVertical = chunkCountVertical;
                RunTime_Terrain_Convertion.convertInfo.vertexCountHorizontal = vertexCountHorizontal;
                RunTime_Terrain_Convertion.convertInfo.vertexCountVertical = vertexCountVertical;
                RunTime_Terrain_Convertion.attachMeshCollider = attachMeshCollider;
                RunTime_Terrain_Convertion.generateBasemap = generateBasemap;
                RunTime_Terrain_Convertion.TerrianToMesh();
            }

            if (GUILayout.Button("创建场景中选中的Terrian创建Mesh", GUILayout.MinHeight(20)))
            {
                RunTime_Terrain_Convertion.convertInfo = new TerrainToMesh.TerrainConvertInfo();
                RunTime_Terrain_Convertion.convertInfo.chunkCountHorizontal = chunkCountHorizontal;
                RunTime_Terrain_Convertion.convertInfo.chunkCountVertical = chunkCountVertical;
                RunTime_Terrain_Convertion.convertInfo.vertexCountHorizontal = vertexCountHorizontal;
                RunTime_Terrain_Convertion.convertInfo.vertexCountVertical = vertexCountVertical;
                RunTime_Terrain_Convertion.attachMeshCollider = attachMeshCollider;
                RunTime_Terrain_Convertion.generateBasemap = generateBasemap;
                RunTime_Terrain_Convertion.CreateByTerrians(selectedGameObjects);
            }
            if (GUILayout.Button("合并选中的mesh为一个临时mesh", GUILayout.MinHeight(20)))
            {
                List<MeshFilter> meshFilters = new List<MeshFilter>();
                for (int i = 0; i < selectedGameObjects.Length; i++)
                {
                    MeshFilter aFilter = selectedGameObjects[i].GetComponent<MeshFilter>();
                    if (aFilter != null)
                    {
                        meshFilters.Add(aFilter);
                    }
                }
                CombineInstance[] combineInstances = new CombineInstance[meshFilters.Count]; //新建一个合并组，长度与 meshfilters一致
                for (int i = 0; i < meshFilters.Count; i++)                                  //遍历
                {
                    combineInstances[i].mesh = meshFilters[i].sharedMesh;                   //将共享mesh，赋值
                    combineInstances[i].transform = meshFilters[i].transform.localToWorldMatrix; //本地坐标转矩阵，赋值
                }
                Mesh newMesh = new Mesh();                                  //声明一个新网格对象
                newMesh.CombineMeshes(combineInstances);                    //将combineInstances数组传入函数
                GameObject meshObj = new GameObject();
                meshObj.name = "CombinedMeshObject";
                meshObj.AddComponent<MeshFilter>().sharedMesh = newMesh; //给当前空物体，添加网格组件；将合并后的网格，给到自身网格
                meshObj.AddComponent<MeshRenderer>();

                RunTime_Terrain_Convertion.ExportUtil.Save<Mesh>(newMesh, string.Concat("CombinedMeshObjectMesh.mesh"));
            }
        }


        void OnInspectorUpdate()
        {
            //这里开启窗口的重绘，不然窗口信息不会刷新
            this.Repaint();
        }

        void OnSelectionChange()
        {
            //当窗口出去开启状态，并且在Hierarchy视图中选择某游戏对象时调用
            selectedGameObjects = Selection.gameObjects;
        }
    }
}
