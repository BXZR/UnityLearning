require 'signatured3'
print('signatured1: this source was signatured!')